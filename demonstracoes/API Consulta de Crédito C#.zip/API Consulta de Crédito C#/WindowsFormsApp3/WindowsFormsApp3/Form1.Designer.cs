﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CNPJUsuario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TOKENSH = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CNPJSH = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCadastrarCNPJ = new System.Windows.Forms.Button();
            this.EmailResponsavelContrato = new System.Windows.Forms.TextBox();
            this.TelefoneResponsavelContrato = new System.Windows.Forms.TextBox();
            this.NomeResponsavelContrato = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.UF = new System.Windows.Forms.TextBox();
            this.cidade = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.CEP = new System.Windows.Forms.TextBox();
            this.bairro = new System.Windows.Forms.TextBox();
            this.complemento = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.NumeroEndereco = new System.Windows.Forms.TextBox();
            this.endereço = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Telefone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.CPFRepresentante = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.NomeRepresentante = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.CNPJ = new System.Windows.Forms.TextBox();
            this.razaoSocial = new System.Windows.Forms.TextBox();
            this.nomeFantasia = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbRazaosocial = new System.Windows.Forms.Label();
            this.lblnomeFantasia = new System.Windows.Forms.Label();
            this.webRetorno = new System.Windows.Forms.WebBrowser();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtUF = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.btnConsultarProtocolo = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.txtProtocolo = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.cbbTipo = new System.Windows.Forms.ComboBox();
            this.txtDocumento = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CNPJUsuario);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.TOKENSH);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.CNPJSH);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(180, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(554, 69);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Headers";
            // 
            // CNPJUsuario
            // 
            this.CNPJUsuario.Location = new System.Drawing.Point(375, 43);
            this.CNPJUsuario.Name = "CNPJUsuario";
            this.CNPJUsuario.Size = new System.Drawing.Size(163, 20);
            this.CNPJUsuario.TabIndex = 5;
            this.CNPJUsuario.Text = "01001001000113";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(372, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "CNPJ Usuário";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // TOKENSH
            // 
            this.TOKENSH.Location = new System.Drawing.Point(199, 43);
            this.TOKENSH.Name = "TOKENSH";
            this.TOKENSH.PasswordChar = '*';
            this.TOKENSH.Size = new System.Drawing.Size(156, 20);
            this.TOKENSH.TabIndex = 3;
            this.TOKENSH.Text = "CdEZhJcQJS9rRdkLnx2Kl67GhAeBx89X2hzgVQ8i";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(196, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Token Software House";
            // 
            // CNPJSH
            // 
            this.CNPJSH.Location = new System.Drawing.Point(18, 43);
            this.CNPJSH.Name = "CNPJSH";
            this.CNPJSH.Size = new System.Drawing.Size(160, 20);
            this.CNPJSH.TabIndex = 1;
            this.CNPJSH.Text = "01001001000113";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CNPJ Software House";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnCadastrarCNPJ);
            this.groupBox2.Controls.Add(this.EmailResponsavelContrato);
            this.groupBox2.Controls.Add(this.TelefoneResponsavelContrato);
            this.groupBox2.Controls.Add(this.NomeResponsavelContrato);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.UF);
            this.groupBox2.Controls.Add(this.cidade);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.CEP);
            this.groupBox2.Controls.Add(this.bairro);
            this.groupBox2.Controls.Add(this.complemento);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.NumeroEndereco);
            this.groupBox2.Controls.Add(this.endereço);
            this.groupBox2.Controls.Add(this.email);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.Telefone);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.CPFRepresentante);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.NomeRepresentante);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.CNPJ);
            this.groupBox2.Controls.Add(this.razaoSocial);
            this.groupBox2.Controls.Add(this.nomeFantasia);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.lbRazaosocial);
            this.groupBox2.Controls.Add(this.lblnomeFantasia);
            this.groupBox2.Location = new System.Drawing.Point(6, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(416, 443);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cadastro CNPJ";
            // 
            // btnCadastrarCNPJ
            // 
            this.btnCadastrarCNPJ.Location = new System.Drawing.Point(140, 341);
            this.btnCadastrarCNPJ.Name = "btnCadastrarCNPJ";
            this.btnCadastrarCNPJ.Size = new System.Drawing.Size(113, 24);
            this.btnCadastrarCNPJ.TabIndex = 34;
            this.btnCadastrarCNPJ.Text = "Cadastrar";
            this.btnCadastrarCNPJ.UseVisualStyleBackColor = true;
            this.btnCadastrarCNPJ.Click += new System.EventHandler(this.btnCadastrarCNPJ_Click);
            // 
            // EmailResponsavelContrato
            // 
            this.EmailResponsavelContrato.Location = new System.Drawing.Point(261, 294);
            this.EmailResponsavelContrato.Name = "EmailResponsavelContrato";
            this.EmailResponsavelContrato.Size = new System.Drawing.Size(120, 20);
            this.EmailResponsavelContrato.TabIndex = 33;
            // 
            // TelefoneResponsavelContrato
            // 
            this.TelefoneResponsavelContrato.Location = new System.Drawing.Point(135, 294);
            this.TelefoneResponsavelContrato.Name = "TelefoneResponsavelContrato";
            this.TelefoneResponsavelContrato.Size = new System.Drawing.Size(114, 20);
            this.TelefoneResponsavelContrato.TabIndex = 32;
            // 
            // NomeResponsavelContrato
            // 
            this.NomeResponsavelContrato.Location = new System.Drawing.Point(9, 294);
            this.NomeResponsavelContrato.Name = "NomeResponsavelContrato";
            this.NomeResponsavelContrato.Size = new System.Drawing.Size(115, 20);
            this.NomeResponsavelContrato.TabIndex = 31;
            this.NomeResponsavelContrato.TextChanged += new System.EventHandler(this.NomeResponsavelContrato_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(267, 278);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(106, 13);
            this.label18.TabIndex = 30;
            this.label18.Text = "Email Resp. Contrato";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(132, 278);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(123, 13);
            this.label17.TabIndex = 29;
            this.label17.Text = "Telefone Resp. Contrato";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 278);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(109, 13);
            this.label16.TabIndex = 28;
            this.label16.Text = "Nome Resp. Contrato";
            // 
            // UF
            // 
            this.UF.Location = new System.Drawing.Point(135, 244);
            this.UF.Name = "UF";
            this.UF.Size = new System.Drawing.Size(114, 20);
            this.UF.TabIndex = 27;
            // 
            // cidade
            // 
            this.cidade.Location = new System.Drawing.Point(6, 244);
            this.cidade.Name = "cidade";
            this.cidade.Size = new System.Drawing.Size(115, 20);
            this.cidade.TabIndex = 26;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(135, 229);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 13);
            this.label15.TabIndex = 25;
            this.label15.Text = "UF";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 228);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 24;
            this.label14.Text = "Cidade";
            // 
            // CEP
            // 
            this.CEP.Location = new System.Drawing.Point(263, 193);
            this.CEP.Name = "CEP";
            this.CEP.Size = new System.Drawing.Size(121, 20);
            this.CEP.TabIndex = 23;
            // 
            // bairro
            // 
            this.bairro.Location = new System.Drawing.Point(133, 193);
            this.bairro.Name = "bairro";
            this.bairro.Size = new System.Drawing.Size(117, 20);
            this.bairro.TabIndex = 22;
            // 
            // complemento
            // 
            this.complemento.Location = new System.Drawing.Point(6, 193);
            this.complemento.Name = "complemento";
            this.complemento.Size = new System.Drawing.Size(115, 20);
            this.complemento.TabIndex = 21;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(267, 177);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(28, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "CEP";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(138, 177);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "Bairro";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 177);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Complemento";
            // 
            // NumeroEndereco
            // 
            this.NumeroEndereco.Location = new System.Drawing.Point(263, 143);
            this.NumeroEndereco.Name = "NumeroEndereco";
            this.NumeroEndereco.Size = new System.Drawing.Size(121, 20);
            this.NumeroEndereco.TabIndex = 17;
            // 
            // endereço
            // 
            this.endereço.Location = new System.Drawing.Point(133, 141);
            this.endereço.Name = "endereço";
            this.endereço.Size = new System.Drawing.Size(117, 20);
            this.endereço.TabIndex = 16;
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(6, 141);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(115, 20);
            this.email.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(266, 125);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Número Endereço";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(137, 125);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Endereço";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Email";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // Telefone
            // 
            this.Telefone.Location = new System.Drawing.Point(263, 92);
            this.Telefone.Name = "Telefone";
            this.Telefone.Size = new System.Drawing.Size(122, 20);
            this.Telefone.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(266, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Telefone";
            // 
            // CPFRepresentante
            // 
            this.CPFRepresentante.Location = new System.Drawing.Point(133, 92);
            this.CPFRepresentante.Name = "CPFRepresentante";
            this.CPFRepresentante.Size = new System.Drawing.Size(117, 20);
            this.CPFRepresentante.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(137, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "CPF Representante";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // NomeRepresentante
            // 
            this.NomeRepresentante.Location = new System.Drawing.Point(6, 92);
            this.NomeRepresentante.Name = "NomeRepresentante";
            this.NomeRepresentante.Size = new System.Drawing.Size(115, 20);
            this.NomeRepresentante.TabIndex = 7;
            this.NomeRepresentante.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Nome Representante";
            // 
            // CNPJ
            // 
            this.CNPJ.Location = new System.Drawing.Point(263, 42);
            this.CNPJ.Name = "CNPJ";
            this.CNPJ.Size = new System.Drawing.Size(123, 20);
            this.CNPJ.TabIndex = 5;
            // 
            // razaoSocial
            // 
            this.razaoSocial.Location = new System.Drawing.Point(133, 42);
            this.razaoSocial.Name = "razaoSocial";
            this.razaoSocial.Size = new System.Drawing.Size(117, 20);
            this.razaoSocial.TabIndex = 4;
            this.razaoSocial.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // nomeFantasia
            // 
            this.nomeFantasia.Location = new System.Drawing.Point(6, 42);
            this.nomeFantasia.Name = "nomeFantasia";
            this.nomeFantasia.Size = new System.Drawing.Size(115, 20);
            this.nomeFantasia.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(266, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "CNPJ";
            // 
            // lbRazaosocial
            // 
            this.lbRazaosocial.AutoSize = true;
            this.lbRazaosocial.Location = new System.Drawing.Point(137, 26);
            this.lbRazaosocial.Name = "lbRazaosocial";
            this.lbRazaosocial.Size = new System.Drawing.Size(70, 13);
            this.lbRazaosocial.TabIndex = 1;
            this.lbRazaosocial.Text = "Razão Social";
            // 
            // lblnomeFantasia
            // 
            this.lblnomeFantasia.AutoSize = true;
            this.lblnomeFantasia.Location = new System.Drawing.Point(6, 26);
            this.lblnomeFantasia.Name = "lblnomeFantasia";
            this.lblnomeFantasia.Size = new System.Drawing.Size(78, 13);
            this.lblnomeFantasia.TabIndex = 0;
            this.lblnomeFantasia.Text = "Nome Fantasia";
            // 
            // webRetorno
            // 
            this.webRetorno.Location = new System.Drawing.Point(428, 264);
            this.webRetorno.MinimumSize = new System.Drawing.Size(20, 20);
            this.webRetorno.Name = "webRetorno";
            this.webRetorno.Size = new System.Drawing.Size(539, 266);
            this.webRetorno.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.txtUF);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.btnConsultarProtocolo);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.txtProtocolo);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.cbbTipo);
            this.groupBox3.Controls.Add(this.txtDocumento);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.txtSenha);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.txtLogin);
            this.groupBox3.Location = new System.Drawing.Point(428, 87);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(524, 171);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Consulta";
            // 
            // txtUF
            // 
            this.txtUF.Location = new System.Drawing.Point(51, 143);
            this.txtUF.Name = "txtUF";
            this.txtUF.Size = new System.Drawing.Size(40, 20);
            this.txtUF.TabIndex = 13;
            this.txtUF.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(24, 146);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(21, 13);
            this.label24.TabIndex = 12;
            this.label24.Text = "UF";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // btnConsultarProtocolo
            // 
            this.btnConsultarProtocolo.Location = new System.Drawing.Point(297, 125);
            this.btnConsultarProtocolo.Name = "btnConsultarProtocolo";
            this.btnConsultarProtocolo.Size = new System.Drawing.Size(130, 20);
            this.btnConsultarProtocolo.TabIndex = 11;
            this.btnConsultarProtocolo.Text = "Consultar Protocolo";
            this.btnConsultarProtocolo.UseVisualStyleBackColor = true;
            this.btnConsultarProtocolo.Click += new System.EventHandler(this.btnConsultarProtocolo_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(268, 83);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 13);
            this.label23.TabIndex = 10;
            this.label23.Text = "Protocolo";
            // 
            // txtProtocolo
            // 
            this.txtProtocolo.Location = new System.Drawing.Point(271, 99);
            this.txtProtocolo.Name = "txtProtocolo";
            this.txtProtocolo.Size = new System.Drawing.Size(182, 20);
            this.txtProtocolo.TabIndex = 9;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(297, 58);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 20);
            this.button1.TabIndex = 8;
            this.button1.Text = "Solicitar Consulta";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(22, 96);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(28, 13);
            this.label22.TabIndex = 7;
            this.label22.Text = "Tipo";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // cbbTipo
            // 
            this.cbbTipo.FormattingEnabled = true;
            this.cbbTipo.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cbbTipo.Location = new System.Drawing.Point(25, 112);
            this.cbbTipo.Name = "cbbTipo";
            this.cbbTipo.Size = new System.Drawing.Size(173, 21);
            this.cbbTipo.TabIndex = 6;
            this.cbbTipo.Text = "Tipo Consulta";
            // 
            // txtDocumento
            // 
            this.txtDocumento.Location = new System.Drawing.Point(27, 73);
            this.txtDocumento.Name = "txtDocumento";
            this.txtDocumento.Size = new System.Drawing.Size(171, 20);
            this.txtDocumento.TabIndex = 5;
            this.txtDocumento.Text = "01001001000113";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(24, 58);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(62, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Documento";
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(271, 32);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.PasswordChar = '*';
            this.txtSenha.Size = new System.Drawing.Size(183, 20);
            this.txtSenha.TabIndex = 3;
            this.txtSenha.Text = "H0M0L0G4";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(268, 16);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(38, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "Senha";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(24, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Login";
            // 
            // txtLogin
            // 
            this.txtLogin.Location = new System.Drawing.Point(27, 32);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(171, 20);
            this.txtLogin.TabIndex = 0;
            this.txtLogin.Text = "5724232";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(92, 150);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(138, 13);
            this.label25.TabIndex = 14;
            this.label25.Text = "*Obrigatório para tipos 1 e 4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 529);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.webRetorno);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox CNPJSH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TOKENSH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox CNPJUsuario;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox CNPJ;
        private System.Windows.Forms.TextBox razaoSocial;
        private System.Windows.Forms.TextBox nomeFantasia;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbRazaosocial;
        private System.Windows.Forms.Label lblnomeFantasia;
        private System.Windows.Forms.TextBox NomeRepresentante;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox CPFRepresentante;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Telefone;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox NumeroEndereco;
        private System.Windows.Forms.TextBox endereço;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox complemento;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox UF;
        private System.Windows.Forms.TextBox cidade;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox CEP;
        private System.Windows.Forms.TextBox bairro;
        private System.Windows.Forms.Button btnCadastrarCNPJ;
        private System.Windows.Forms.TextBox EmailResponsavelContrato;
        private System.Windows.Forms.TextBox TelefoneResponsavelContrato;
        private System.Windows.Forms.TextBox NomeResponsavelContrato;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.WebBrowser webRetorno;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.ComboBox cbbTipo;
        private System.Windows.Forms.TextBox txtDocumento;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtProtocolo;
        private System.Windows.Forms.Button btnConsultarProtocolo;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtUF;
        private System.Windows.Forms.Label label25;
    }
}

