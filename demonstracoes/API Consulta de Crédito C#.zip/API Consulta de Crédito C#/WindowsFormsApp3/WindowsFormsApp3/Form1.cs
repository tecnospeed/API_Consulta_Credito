﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastrarCNPJ_Click(object sender, EventArgs e)
        {
            string cnpjSH = CNPJSH.Text;
            string tokenSH = TOKENSH.Text;
            string cnpjUsuario = CNPJUsuario.Text;
            string url;

            var objCamposCadastroCNPJ = new
            {
                nomeFantasia = nomeFantasia.Text,
                razaoSocial = razaoSocial.Text,
                cnpj = CNPJ.Text,
                nomeRepresentante = NomeRepresentante.Text,
                cpfRepresentante = CPFRepresentante.Text,
                telefone = Telefone.Text,
                email = email.Text,
                endereco = endereço.Text,
                numeroEndereco = NumeroEndereco.Text,
                complementoEndereco = complemento.Text,
                bairro = bairro.Text,
                cep = CEP.Text,
                cidade = cidade.Text,
                uf = UF.Text,
                nomeResponsavelContrato = NomeRepresentante.Text,
                telefoneResponsavelContrato = TelefoneResponsavelContrato.Text,
                emailResponsavelContrato = EmailResponsavelContrato.Text
            };

            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJson = js.Serialize(objCamposCadastroCNPJ);

            //Inicia a configuração da requisicao. Este trecho não deve ser usado em homologação.
            
            var client = new RestClient("http://ecs-consulta-credito-api-1312101438.us-east-1.elb.amazonaws.com/cadastros");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("cnpjSh", CNPJSH.Text);
            request.AddHeader("tokenSh", TOKENSH.Text);
            
            request.AddParameter("application/json", strJson, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            webRetorno.DocumentText = JsonConvert.SerializeObject(json, Formatting.Indented); 
            }

        private void NomeResponsavelContrato_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            var client = new RestClient("http://ecs-consulta-credito-api-1312101438.us-east-1.elb.amazonaws.com/consultas/assincrona/homologacao");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("cnpjSh", CNPJSH.Text);
            request.AddHeader("tokenSh", TOKENSH.Text);
            request.AddHeader("cnpjUsuario", CNPJUsuario.Text);
            request.AddHeader("login", txtLogin.Text);
            request.AddHeader("password", txtSenha.Text);

            string tipoConsulta = "0";

            if (cbbTipo.SelectedIndex == 0)
            {
                tipoConsulta = "1";
           
                if (txtUF.Text == null)
                {
                    MessageBox.Show("Dados Obrigatórios não preenchidos!", "Alerta!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else if (cbbTipo.SelectedIndex == 1)
            {
                tipoConsulta = "2";
                
            }
            else if (cbbTipo.SelectedIndex == 2)
            {
                tipoConsulta = "3";
                
            }
            else if (cbbTipo.SelectedIndex == 3)
            {
                tipoConsulta = "4";
                if (txtUF.Text == null)
                {
                    MessageBox.Show("Dados Obrigatórios não preenchidos!", "Alerta!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
                        
                if (tipoConsulta == "1" || tipoConsulta == "4")
            {
                var objCamposConsulta = new
                {
                    documento = txtDocumento.Text,
                    codConsulta = tipoConsulta,
                    uf = txtUF.Text,
             };                     
                      
            JavaScriptSerializer js = new JavaScriptSerializer();            
            dynamic json = js.Serialize(objCamposConsulta);
            request.AddParameter("application/json", json, ParameterType.RequestBody);
            string jsonResposta = client.Execute(request).Content;
            webRetorno.DocumentText = jsonResposta;
            SolicitarConsulta obj = JsonConvert.DeserializeObject<SolicitarConsulta>(jsonResposta);
            txtProtocolo.Text = obj.Protocolo;
            }
            else if (tipoConsulta == "2" || tipoConsulta == "3"){

                var objCamposConsulta = new
                {
                    documento = txtDocumento.Text,
                    codConsulta = tipoConsulta,
                   
                };

                JavaScriptSerializer js = new JavaScriptSerializer();
                dynamic json = js.Serialize(objCamposConsulta);
                request.AddParameter("application/json", json, ParameterType.RequestBody);
                string jsonResposta = client.Execute(request).Content;
                webRetorno.DocumentText = jsonResposta;
                SolicitarConsulta obj = JsonConvert.DeserializeObject<SolicitarConsulta>(jsonResposta);
                txtProtocolo.Text = obj.Protocolo;
            }
        }

        private void btnConsultarProtocolo_Click(object sender, EventArgs e)
        {
            var client = new RestClient("http://ecs-consulta-credito-api-1312101438.us-east-1.elb.amazonaws.com/consultas/assincrona?protocolo=" +txtProtocolo.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("cnpjSh", CNPJSH.Text);
            request.AddHeader("tokenSh", TOKENSH.Text);
            request.AddHeader("cnpjUsuario", CNPJUsuario.Text);
            request.AddHeader("login", txtLogin.Text);
            request.AddHeader("password", txtSenha.Text);

            request.AddParameter("application/json", ParameterType.RequestBody);
            webRetorno.DocumentText = client.Execute(request).Content;
        }


        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        public partial class SolicitarConsulta
        {
            [JsonProperty("protocolo")]
            public string Protocolo { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }

            [JsonProperty("documento")]
            public string Documento { get; set; }

            [JsonProperty("codConsulta")]
            public string CodConsulta { get; set; }
               
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
