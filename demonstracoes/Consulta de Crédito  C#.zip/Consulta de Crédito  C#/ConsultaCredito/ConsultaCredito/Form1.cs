﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;

/*Para compilar:
Project > Manager NuGet Packages 
Instale o pacote "RestSharp" 106.6.9

Dicas importantes:
Documentação: https://atendimento.tecnospeed.com.br/hc/pt-br/categories/360001954693-Consulta-de-Credito
 */

namespace ConsultaCredito
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        
        private void label1_Click(object sender, EventArgs e)
        {

        }

        

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            string tipoConsulta = "0";

            if (cbTipo.SelectedIndex == 0)
            {
                tipoConsulta = "1";
            }
            else if (cbTipo.SelectedIndex == 1)
            {
                tipoConsulta = "2";
            }
            else if (cbTipo.SelectedIndex == 2)
            {
                tipoConsulta = "3";
            }
            else if (cbTipo.SelectedIndex == 3)
            {
                tipoConsulta = "4";
            }
         

            var client = new RestClient("https://5uofolab63.execute-api.us-east-1.amazonaws.com/production/consultas/homologacao?" 
                + "login=" + tbLogin.Text + "&senha=" + tbSenha.Text + "&tipo=" + tipoConsulta + "&documento=" + tbCPFCNPJ.Text);
            var request = new RestRequest(Method.GET);
            //request.AddHeader("cache-control", "no-cache");
            //request.AddHeader("content-type", "application/json");
            request.AddHeader("cnpjSh", tbCNPJSH.Text);
            request.AddHeader("tokenSh", tbTokenSH.Text);

            wbRetorno.DocumentText = client.Execute(request).Content;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbTipo.SelectedIndex = 0;
        }
    }
}
