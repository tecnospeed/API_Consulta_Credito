﻿namespace ConsultaCredito
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbTokenSH = new System.Windows.Forms.TextBox();
            this.tbCNPJSH = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbTipo = new System.Windows.Forms.ComboBox();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.tbSenha = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.tbCPFCNPJ = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.wbRetorno = new System.Windows.Forms.WebBrowser();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbTokenSH);
            this.groupBox1.Controls.Add(this.tbCNPJSH);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(317, 86);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " Configurar Software House ";
            // 
            // tbTokenSH
            // 
            this.tbTokenSH.Location = new System.Drawing.Point(90, 50);
            this.tbTokenSH.Name = "tbTokenSH";
            this.tbTokenSH.Size = new System.Drawing.Size(215, 20);
            this.tbTokenSH.TabIndex = 3;
            this.tbTokenSH.Text = "CdEZhJcQJS9rRdkLnx2Kl67GhAeBx89X2hzgVQ8i";
            // 
            // tbCNPJSH
            // 
            this.tbCNPJSH.Location = new System.Drawing.Point(90, 19);
            this.tbCNPJSH.Name = "tbCNPJSH";
            this.tbCNPJSH.Size = new System.Drawing.Size(216, 20);
            this.tbCNPJSH.TabIndex = 2;
            this.tbCNPJSH.Text = "01001001000113";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Token SH";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CNPJ SH";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbTipo);
            this.groupBox2.Controls.Add(this.tbLogin);
            this.groupBox2.Controls.Add(this.tbSenha);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.btnConsultar);
            this.groupBox2.Controls.Add(this.tbCPFCNPJ);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(12, 116);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(317, 257);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " Consultar ";
            // 
            // cbTipo
            // 
            this.cbTipo.FormattingEnabled = true;
            this.cbTipo.Items.AddRange(new object[] {
            "Crednet PF TOP",
            "Credit Bureau PF Top Score",
            "Concentre PF TOP Score",
            "Crednet Light"});
            this.cbTipo.Location = new System.Drawing.Point(91, 109);
            this.cbTipo.Name = "cbTipo";
            this.cbTipo.Size = new System.Drawing.Size(215, 21);
            this.cbTipo.TabIndex = 12;
            // 
            // tbLogin
            // 
            this.tbLogin.Location = new System.Drawing.Point(90, 23);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbLogin.Size = new System.Drawing.Size(215, 20);
            this.tbLogin.TabIndex = 11;
            this.tbLogin.Text = "5724232";
            this.tbLogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbSenha
            // 
            this.tbSenha.Location = new System.Drawing.Point(90, 64);
            this.tbSenha.Name = "tbSenha";
            this.tbSenha.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbSenha.Size = new System.Drawing.Size(215, 20);
            this.tbSenha.TabIndex = 10;
            this.tbSenha.Text = "H0M0L0G4";
            this.tbSenha.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Tipo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Senha";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Login";
            // 
            // btnConsultar
            // 
            this.btnConsultar.Location = new System.Drawing.Point(207, 218);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(98, 23);
            this.btnConsultar.TabIndex = 5;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // 
            // tbCPFCNPJ
            // 
            this.tbCPFCNPJ.Location = new System.Drawing.Point(91, 149);
            this.tbCPFCNPJ.Name = "tbCPFCNPJ";
            this.tbCPFCNPJ.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbCPFCNPJ.Size = new System.Drawing.Size(215, 20);
            this.tbCPFCNPJ.TabIndex = 4;
            this.tbCPFCNPJ.Text = "01001001000113";
            this.tbCPFCNPJ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Documento";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // wbRetorno
            // 
            this.wbRetorno.Location = new System.Drawing.Point(346, 15);
            this.wbRetorno.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbRetorno.Name = "wbRetorno";
            this.wbRetorno.Size = new System.Drawing.Size(629, 358);
            this.wbRetorno.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 391);
            this.Controls.Add(this.wbRetorno);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Consulta de Crédito - Tecnospeed";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbTokenSH;
        private System.Windows.Forms.TextBox tbCNPJSH;
        private System.Windows.Forms.TextBox tbCPFCNPJ;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.WebBrowser wbRetorno;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbTipo;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.TextBox tbSenha;
    }
}

