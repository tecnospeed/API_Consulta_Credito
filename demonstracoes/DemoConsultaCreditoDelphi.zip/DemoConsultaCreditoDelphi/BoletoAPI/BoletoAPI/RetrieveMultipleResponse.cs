﻿namespace BoletoAPI
{
    internal class RetrieveMultipleResponse
    {
    }
}