﻿namespace BoletoAPI
{
    internal class json
    {
    }
}