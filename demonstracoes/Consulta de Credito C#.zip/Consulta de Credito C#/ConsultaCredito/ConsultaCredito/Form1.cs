﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;



/*Para compilar:
(Project > Manager NuGet Packages )
Instale o pacote "RestSharp" 106.6.9
Instale o pacote "Newtonsoft.Json"
-------
Adicione a referência (Project > Add Reference) System.Web.Extensions ao projeto


Dicas importantes:
Documentação: https://atendimento.tecnospeed.com.br/hc/pt-br/categories/360001954693-Consulta-de-Credito
 */

namespace ConsultaCredito
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        
        private void label1_Click(object sender, EventArgs e)
        {

        }

        

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            string tipoConsulta = "0";

            if (cbTipo.SelectedIndex == 0)
            {
                tipoConsulta = "1";
            }
            else if (cbTipo.SelectedIndex == 1)
            {
                tipoConsulta = "2";
            }
            else if (cbTipo.SelectedIndex == 2)
            {
                tipoConsulta = "3";
            }
            else if (cbTipo.SelectedIndex == 3)
            {
                tipoConsulta = "4";
            }
         

            var client = new RestClient("https://5uofolab63.execute-api.us-east-1.amazonaws.com/production/consultas/homologacao?" 
                + "login=" + tbLogin.Text + "&senha=" + tbSenha.Text + "&tipo=" + tipoConsulta + "&documento=" + tbCPFCNPJ.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("cnpjSh", tbCNPJSH.Text);
            request.AddHeader("tokenSh", tbTokenSH.Text);

            wbRetorno.DocumentText = client.Execute(request).Content;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbTipo.SelectedIndex = 0;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            /* 
             * Método que faz o cadastro do CNPJ na SCC
             * Neste exemplo, o disparo da requisição está comentado pois não existe cadastro em homologação.
             * 
             * Em um cenário real, basta tirar o comentário do trecho de código.
             * 
             */


            //Criando o json com os campos do cadastro:
            var objCamposCadastro = new {
                nomeFantasia = "XYZ",
                razaoSocial = "XYZ Ltda",
                cnpj = "12123123000101",
                nomeRepresentante = "XYZ",
                cpfRepresentante = "12312312312",
                telefone = "44999999999",
                email = "contato@xyz.com.br",
                endereco = "XYZ",
                numeroEndereco = "123",
                complementoEndereco = "XYZ",
                bairro = "XYZ",
                cep = "000000",
                cidade = "XYZ",
                uf = "XY"
            };

            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJson = js.Serialize(objCamposCadastro);



            //Inicia a configuração da requisicao. Este trecho não deve ser usado em homologação.
            /*
            var client = new RestClient("https://u90m7j5mp2.execute-api.us-east-1.amazonaws.com/pro/cadastros");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("cnpjSh", tbCNPJSH.Text);
            request.AddHeader("tokenSh", tbTokenSH.Text);

            request.AddParameter("application/json", strJson, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            wbRetorno.DocumentText = JsonConvert.SerializeObject(json, Formatting.Indented);        
            
            */

            string retornoMock = "{\"status\": \"Aguardando validação da entidade.\",\"statusCode\": 100,\"_id\": \"5ce7eca35aee3c046fa67793\"}";
            retornoMock = JsonConvert.SerializeObject(retornoMock, Formatting.Indented);
            wbRetorno.DocumentText = retornoMock.Replace("\\", "");
            // As 3 linhas acima são um Mock, para que você veja a estrutura do retorno. NÃO IMPLEMENTÁ-LAS EM PRODUÇÃO.
        }
    }
}
