﻿namespace BoletoAPI
{
    public class CamposConvenio
    {
    }
}