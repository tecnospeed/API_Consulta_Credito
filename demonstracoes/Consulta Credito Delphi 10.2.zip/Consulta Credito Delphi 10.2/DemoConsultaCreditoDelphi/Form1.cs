﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.IO;
using System.Windows.Forms;

namespace BoletoAPI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCadastroCedente_Click(object sender, EventArgs e)
        {
            string cnpjSH = txBoxCNPJSH.Text;
            string tokenSH = txBoxTokenSH.Text;
            string cnpjCedente = txBoxCNPJCedente.Text;
            string url;

            if (txBoxCNPJSH.Text == "" | txBoxTokenSH.Text == "" | txBoxCNPJCedente.Text == "")
            {
                MessageBox.Show("Dados Obrigatórios não preenchidos!","Alerta!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            //Verificação do ambiente para montar a requisição
            if (rdHomologacao.Checked)
            {
                url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080";
            }
            else
            {
                url = "https://cobrancabancaria.tecnospeed.com.br";
            }
            //Criando o json com os campos do Json:
            var objCamposCedente = new
            {
                CedenteRazaoSocial = "Empresa Ltda",
                CedenteNomeFantasia = "Empresa",
                CedenteCPFCNPJ = "20841251000106",
                CedenteEnderecoLogradouro = "Av. Analista Jucá de Souza",
                CedenteEnderecoNumero = "123",
                CedenteEnderecoComplemento = "sala 987",
                CedenteEnderecoBairro = "Centro",
                CedenteEnderecoCEP = "87012345",
                CedenteEnderecoCidadeIBGE = "4115200",
                CedenteTelefone = "(44) 3033-1234",
                CedenteEmail = "cobranca@boleto.com.br"
            };
            javaScriptSerializer js = new javaScriptSerializer();
            string strJsonCedente = js.Serialize(objCamposCedente);

            var client = new RestClient(url + "/api/v1/cedentes");
            var request = new RestRequest(Method.POST);
            request.AddHeader("Cache-control", "no-cache");
            request.AddHeader("Content-type", "Application/json");
            request.AddHeader("Token-sh", tokenSH);
            request.AddHeader("CNPJ-sh", cnpjSH);
            request.AddParameter("application/json", strJsonCedente, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented); 
        }

        private void btnCadastroConta_Click(object sender, EventArgs e)
        {
         string cnpjSH = txBoxCNPJSH.Text;
         string tokenSH = txBoxTokenSH.Text;
         string cnpjCedente = txBoxCNPJCedente.Text;
         string url;

         if (txBoxCNPJSH.Text == "" | txBoxTokenSH.Text == "" | txBoxCNPJCedente.Text == "")
            {
                MessageBox.Show("Dados Obrigatórios não preencidos!", "Alerta!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            //Verificação do ambiente para montar a requisição
            if (rdHomologacao.Checked)
            {
                url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080";
            }
            else
            {
                url = "https://cobrancabancaria.tecnospeed.com.br";
            }
            //Criando o json com os campos do Json:
            var objCamposBoleto = new
            {
                ContaCodigoBanco = "341",
                ContaAgencia = "4233",
                ContaAgenciaDV = "",
                ContaNumero = "54321",
                ContaNumeroDV = "0",
                ContaTipo = "CORRENTE",
                ContaCodigoBeneficiario = "54321"
            };
            javaScriptSerializer js = new javaScriptSerializer();
            string strJsonCedente = js.Serialize(objCamposBoleto);

            // config da requisição:
            var client = new RestClient(url + "/api/v1/cedentes/contas");
            var request = new RestRequest(Method.POST);
            request.AddHeader("Cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", strJsonCedente, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnCadastroConvenio_Click(object sender, EventArgs e)
        {
            string cnpjSH = txBoxCNPJSH.Text;
            string tokenSH = txBoxTokenSH.Text;
            string cnpjCedente = txBoxCNPJCedente.Text;
            string url;

            if (txBoxCNPJSH.Text == "" | txBoxTokenSH.Text == "" | txBoxCNPJCedente.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            //Verificação do ambiente para montar a requisição
            if (rdHomologacao.Checked)
            {
                url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080";
            }
            else
            {
                url = "https://cobrancabancaria.tecnospeed.com.br";
            }
            //Criando o json com os campos do Json:
            var objCamposConvenio = new
            {
                ConvenioNumero = "321",
                ConvenioDescricao = "Carteira de exemplo",
                ConvenioCarteira = "109",
                ConvenioEspecie = "Boleto",
                ConvenioPadraoCNAB = "240",
                ConvenioAtualizaVan = "0",
                Conta = "954"
            };
            javaScriptSerializer js = new javaScriptSerializer();
            string strJsonCedente = js.Serialize(objCamposConvenio);

            //config da requisição

            var client = new RestClient(url + "/api/v1/cedentes/contas/convenios");
            var request = new RestRequest(Method.POST);
            request.AddHeader("Cache-control", "No-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", strJsonCedente, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnSolicitarImpressao_Click(object sender, EventArgs e)
        {
            string cnpjSH = txBoxCNPJSH.Text;
            string tokenSH = txBoxTokenSH.Text;
            string cnpjCedente = txBoxCNPJCedente.Text;
            string url;

            if (txBoxCNPJSH.Text == "" | txBoxTokenSH.Text == "" | txBoxCNPJCedente.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            //Verificação do ambiente para montar a requisição
            if (rdHomologacao.Checked)
            {
                url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080";
            }
            else
            {
                url = "https://cobrancabancaria.tecnospeed.com.br";
            }

            //Cria um array com od idIntegração, separados por virgula
            string[] idIntegracaoArray;
            idIntegracaoArray = txtIDIntegracao.Text.Split(',');

            string JsonCompletoImpressaoLote = "";

            if (cbbTipoImpressao.SelectedIndex == 0)
            {
                string FormatoImpressao = "0";  //Normal
                var jsonImpressaoLote = new
                {
                    tipoImpressao = FormatoImpressao,
                    boletos = idIntegracaoArray
                };
                javaScriptSerializer js = new javaScriptSerializer();
                JsonCompletoImpressaoLote = js.Serialize(jsonImpressaoLote); //fim do JSON
                txtRetorno.Text = JsonCompletoImpressaoLote;
            }
            else if (cbbTipoImpressao.SelectedIndex == 1)
            {
                string FormatoImpressao = "1";  //carnê duplo
                var jsonImpressaoLote = new
                {
                    tipoImpressao = FormatoImpressao,
                    boletos = idIntegracaoArray
                };
                javaScriptSerializer js = new javaScriptSerializer();
                JsonCompletoImpressaoLote = js.Serialize(jsonImpressaoLote);
                txtRetorno.Text = JsonCompletoImpressaoLote;
            }
            else if (cbbTipoImpressao.SelectedIndex == 2)
            {
                string FormatoImpressao = "2"; //Carnê triplo
                var jsonImpressaoLote = new
                {
                    tipoImpressao = FormatoImpressao,
                    boletos = idIntegracaoArray
                };
                javaScriptSerializer js = new javaScriptSerializer();
                JsonCompletoImpressaoLote = js.Serialize(jsonImpressaoLote);
                txtRetorno.Text = JsonCompletoImpressaoLote;
            }
            else if (cbbTipoImpressao.SelectedIndex == 3)
            {
                string FormatoImpressao = "3";  //Impressão Dupla
                var jsonImpressaoLote = new
                {
                    tipoImpressao = FormatoImpressao,
                    boletos = idIntegracaoArray
                };
                javaScriptSerializer js = new javaScriptSerializer();
                JsonCompletoImpressaoLote = js.Serialize(jsonImpressaoLote);
                txtRetorno.Text = JsonCompletoImpressaoLote;
            }
            else if (cbbTipoImpressao.SelectedIndex == 4)
            {
                string FormatoImpressao = "4"; //Marca d'agua
                var jsonImpressaoLote = new
                {
                    tipoImpressao = FormatoImpressao,
                    boletos = idIntegracaoArray
                };
                javaScriptSerializer js = new javaScriptSerializer();
                JsonCompletoImpressaoLote = js.Serialize(jsonImpressaoLote);
                txtRetorno.Text = JsonCompletoImpressaoLote;                     
            }
            else
            {
                string FormatoImpressao = "99";  //personalizada
                var jsonImpressaoLote = new
                {
                    tipoImpressao = FormatoImpressao,
                    boletos = idIntegracaoArray
                };
                javaScriptSerializer js = new javaScriptSerializer();
                JsonCompletoImpressaoLote = js.Serialize(jsonImpressaoLote);
                txtRetorno.Text = JsonCompletoImpressaoLote;
            }

            // config da requisição:
            var client = new RestClient(url + "/api/v1/boletos/impressao/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", JsonCompletoImpressaoLote, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void cbbTipoImpressao_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        public string TrocaVirgulaPorE(string listaIdIntegracao)
        {
            //Metodo implementado apenas para facilitar a informação do idINtegracao na tela. Ele troca a vírgula que separa os idIntegracao pelo "&idintegracao" que será usado na rota
            string auxiliar;
            auxiliar = listaIdIntegracao.Replace(",", "&idintegracao=");
            return auxiliar;
        }

        private void btnConsultarImpressao_Click(object sender, EventArgs e)
        {

            string cnpjSH = txBoxCNPJSH.Text;
            string tokenSH = txBoxTokenSH.Text;
            string cnpjCedente = txBoxCNPJCedente.Text;
            string url;

            if (txBoxCNPJSH.Text == "" | txBoxTokenSH.Text == "" | txBoxCNPJCedente.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            if (rdHomologacao.Checked)
            {
                url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080";
            }
            else url = "https://cobrancabancaria.tecnospeed.com.br";

            var client = new RestClient(url + "/api/v1/boletos/impressao/lote/" + txtProtocoloImpressao.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/pdf");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);

            byte[] response = client.DownloadData(request);
            File.WriteAllBytes(@ "C:\Temp\TesteImpressao.pdf", response);  //Salva conteúdo do pdf

            txtRetorno.Text = "PDF Salvo em C:\\Temp\\TesteImpressao.pdf !";
        }

        private void btnIncluirBoleto_Click(object sender, EventArgs e)
        {
            string cnpjSH = txBoxCNPJSH.Text;
            string tokenSH = txBoxTokenSH.Text;
            string cnpjCedente = txBoxCNPJCedente.Text;
            string url;

            if (txBoxCNPJSH.Text == "" | txBoxTokenSH.Text == "" | txBoxCNPJCedente.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            //Verifica qual o ambiente (produção ou homologação) que será usado para montar a requisição
            if (rdHomologacao.Checked)
            {
                url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080";
            }
            else url = "https://cobrancabancaria.tecnospeed.com.br";

            var objCamposBoleto = new object[] { new
            {
                CedenteContaNumero = "12345",
                CedenteContaNumeroDV = "6",
                CedenteConvenioNumero = "6543231",
                CedenteContaCodigoBanco = "341",
                SacadoCPFCNPJ = "28436161661",
                SacadoEmail = "email@sacado.com",
                SacadoEnderecoNumero = "987",
                SacadoEnderecoBairro = "Centro",
                SacadoEnderecoCEP = "87098765",
                SacadoEnderecoCidade = "Maringá",
                SacadoEnderecoComplemento = "Fundos",
                SacadoEnderecoLogradouro = "Rua teste, 987",
                SacadoEnderecoPais = "Brasil",
                SacadoEnderecoUF = "PR",
                SacadoNome = "Teste de Souza",
                SacadoTelefone = "4499999999",
                SacadoCelular = "44999999999",
                TituloDataDesconto = "05/01/2020",
                TituloValorDesconto = "0,01",
                TituloDataEmissao = "01/01/2020",
                TituloDataVencimento = "01/01/2020",
                TituloValorJuros = "0,01",
                TituloPrazoProtesto = "30",
                TituloMensagem01 = "Juros de 0,01 ao dia",
                TituloMensagem02 = "Nao receber apos 30 dias de atraso",
                TituloMensagem03 = "Titulo sujeito a protesto apos 30 dias",
                TituloNossoNumero ="1254",
                TituloNumeroDocumento = "01012020",
                TituloValor = "0,02",
                TituloLocalPagamento = "Pagável em qualquer banco até o vencimento." }
                //Demais campos disponíveis em: https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360014943693-Campos-utilizados-para-inclus%C3%A3o
            };
            javaScriptSerializer js = new javaScriptSerializer();
            string strJson = js.Serialize(objCamposBoleto);

            var client = new RestClient(url + "/api/v1/boletos/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", strJson, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnConsultarBoleto_Click(object sender, EventArgs e)
        {
            string cnpjSH = txBoxCNPJSH.Text;
            string tokenSH = txBoxTokenSH.Text;
            string cnpjCedente = txBoxCNPJCedente.Text;
            string url;

            if (txBoxCNPJSH.Text == "" | txBoxTokenSH.Text == "" | txBoxCNPJCedente.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if (rdHomologacao.Checked)
            {
                url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080";
            }
            else url = "https://cobrancabancaria.tecnospeed.com.br";

            var client = new RestClient(url + "/api/v1/boletos?" + "idintegracao=" + TrocaVirgulaPorE(txtIDIntegracao.Text));
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }

        private void btnDescartarBoleto_Click(object sender, EventArgs e)
        {

        }

        private void btnEnvioEmail_Click(object sender, EventArgs e)
        {
            string cnpjSH = txBoxCNPJSH.Text;
            string tokenSH = txBoxTokenSH.Text;
            string cnpjCedente = txBoxCNPJCedente.Text;
            string url;

            if (txBoxCNPJSH.Text == "" | txBoxTokenSH.Text == "" | txBoxCNPJCedente.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            //Verifica qual o ambiente (produção ou homologação) que será usado para montar a requisição
            if (rdHomologacao.Checked)
            {
                url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080";
            }
            else url = "https://cobrancabancaria.tecnospeed.com.br";

            var objVet = new
            {
                idIntegracao = txtIDIntegracao.Text,
                EmailNomeRemetente = "Empresa Exemplo",
                EmailRemetente = "guilherme.ganassin@tecnospeed.com.br",
                EmailAssunto = "Boleto para Pagamento",
                EmailMensagem = "Segue o link do boleto: | ${linkBoleto} | Considere nao imprimir este email.",
                EmailDestinatario = "luiz.bengozi@tecnospeed.com.br"
            };

            javaScriptSerializer js = new javaScriptSerializer();
            string strJson = js.Serialize(objVet);
            txtRetorno.Text = strJson;

            //config requisição:
            var client = new RestClient(url + "/api/v1/email/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", (strJson), ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
           
        }

        
    }
}
