﻿using System;

namespace BoletoAPI
{
    internal class javaScriptSerializer
    {
        public javaScriptSerializer()
        {
        }

        internal string Serialize(object objCamposCedente)
        {
            throw new NotImplementedException();
        }
    }
}