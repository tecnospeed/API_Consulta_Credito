﻿namespace BoletoAPI
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.colorDialog3 = new System.Windows.Forms.ColorDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdProducao = new System.Windows.Forms.RadioButton();
            this.rdHomologacao = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txBoxTokenSH = new System.Windows.Forms.TextBox();
            this.txBoxCNPJCedente = new System.Windows.Forms.TextBox();
            this.txBoxCNPJSH = new System.Windows.Forms.TextBox();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnCadastroConvenio = new System.Windows.Forms.Button();
            this.btnCadastroConta = new System.Windows.Forms.Button();
            this.btnCadastroCedente = new System.Windows.Forms.Button();
            this.txtRetorno = new System.Windows.Forms.RichTextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnConsultarImpressao = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtProtocoloImpressao = new System.Windows.Forms.TextBox();
            this.btnSolicitarImpressao = new System.Windows.Forms.Button();
            this.cbbTipoImpressao = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnConsultarBoleto = new System.Windows.Forms.Button();
            this.btnIncluirBoleto = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtIDIntegracao = new System.Windows.Forms.TextBox();
            this.btnDescartarBoleto = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnEnvioEmail = new System.Windows.Forms.Button();
            this.txtProtocoloEmail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnConsultarEmail = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdProducao);
            this.groupBox1.Controls.Add(this.rdHomologacao);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(273, 69);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ambiente";
            // 
            // rdProducao
            // 
            this.rdProducao.AutoSize = true;
            this.rdProducao.Location = new System.Drawing.Point(176, 33);
            this.rdProducao.Name = "rdProducao";
            this.rdProducao.Size = new System.Drawing.Size(71, 17);
            this.rdProducao.TabIndex = 1;
            this.rdProducao.TabStop = true;
            this.rdProducao.Text = "Produção";
            this.rdProducao.UseVisualStyleBackColor = true;
            // 
            // rdHomologacao
            // 
            this.rdHomologacao.AutoSize = true;
            this.rdHomologacao.Location = new System.Drawing.Point(11, 33);
            this.rdHomologacao.Name = "rdHomologacao";
            this.rdHomologacao.Size = new System.Drawing.Size(91, 17);
            this.rdHomologacao.TabIndex = 0;
            this.rdHomologacao.TabStop = true;
            this.rdHomologacao.Text = "Homologação";
            this.rdHomologacao.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txBoxTokenSH);
            this.groupBox2.Controls.Add(this.txBoxCNPJCedente);
            this.groupBox2.Controls.Add(this.txBoxCNPJSH);
            this.groupBox2.Location = new System.Drawing.Point(12, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(273, 116);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Config";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(75, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Token Software House";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(146, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "CNPJ Cedente";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "CNPJ Software House";
            // 
            // txBoxTokenSH
            // 
            this.txBoxTokenSH.Location = new System.Drawing.Point(25, 79);
            this.txBoxTokenSH.Name = "txBoxTokenSH";
            this.txBoxTokenSH.Size = new System.Drawing.Size(221, 20);
            this.txBoxTokenSH.TabIndex = 2;
            // 
            // txBoxCNPJCedente
            // 
            this.txBoxCNPJCedente.Location = new System.Drawing.Point(140, 33);
            this.txBoxCNPJCedente.Name = "txBoxCNPJCedente";
            this.txBoxCNPJCedente.Size = new System.Drawing.Size(127, 20);
            this.txBoxCNPJCedente.TabIndex = 1;
            // 
            // txBoxCNPJSH
            // 
            this.txBoxCNPJSH.Location = new System.Drawing.Point(11, 33);
            this.txBoxCNPJSH.Name = "txBoxCNPJSH";
            this.txBoxCNPJSH.Size = new System.Drawing.Size(114, 20);
            this.txBoxCNPJSH.TabIndex = 0;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnCadastroConvenio);
            this.groupBox3.Controls.Add(this.btnCadastroConta);
            this.groupBox3.Controls.Add(this.btnCadastroCedente);
            this.groupBox3.Location = new System.Drawing.Point(12, 209);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(273, 139);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Cadastro";
            // 
            // btnCadastroConvenio
            // 
            this.btnCadastroConvenio.Location = new System.Drawing.Point(78, 107);
            this.btnCadastroConvenio.Name = "btnCadastroConvenio";
            this.btnCadastroConvenio.Size = new System.Drawing.Size(127, 26);
            this.btnCadastroConvenio.TabIndex = 2;
            this.btnCadastroConvenio.Text = "Cadastrar Convênio";
            this.btnCadastroConvenio.UseVisualStyleBackColor = true;
            this.btnCadastroConvenio.Click += new System.EventHandler(this.btnCadastroConvenio_Click);
            // 
            // btnCadastroConta
            // 
            this.btnCadastroConta.Location = new System.Drawing.Point(78, 61);
            this.btnCadastroConta.Name = "btnCadastroConta";
            this.btnCadastroConta.Size = new System.Drawing.Size(127, 29);
            this.btnCadastroConta.TabIndex = 1;
            this.btnCadastroConta.Text = "Cadastrar Conta";
            this.btnCadastroConta.UseVisualStyleBackColor = true;
            this.btnCadastroConta.Click += new System.EventHandler(this.btnCadastroConta_Click);
            // 
            // btnCadastroCedente
            // 
            this.btnCadastroCedente.Location = new System.Drawing.Point(78, 10);
            this.btnCadastroCedente.Name = "btnCadastroCedente";
            this.btnCadastroCedente.Size = new System.Drawing.Size(127, 30);
            this.btnCadastroCedente.TabIndex = 0;
            this.btnCadastroCedente.Text = "Cadastrar Cedente";
            this.btnCadastroCedente.UseVisualStyleBackColor = true;
            this.btnCadastroCedente.Click += new System.EventHandler(this.btnCadastroCedente_Click);
            // 
            // txtRetorno
            // 
            this.txtRetorno.Location = new System.Drawing.Point(12, 366);
            this.txtRetorno.Name = "txtRetorno";
            this.txtRetorno.Size = new System.Drawing.Size(776, 162);
            this.txtRetorno.TabIndex = 3;
            this.txtRetorno.Text = "";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnConsultarImpressao);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.txtProtocoloImpressao);
            this.groupBox4.Controls.Add(this.btnSolicitarImpressao);
            this.groupBox4.Controls.Add(this.cbbTipoImpressao);
            this.groupBox4.Location = new System.Drawing.Point(291, 86);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(238, 116);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Impressão";
            // 
            // btnConsultarImpressao
            // 
            this.btnConsultarImpressao.Location = new System.Drawing.Point(134, 65);
            this.btnConsultarImpressao.Name = "btnConsultarImpressao";
            this.btnConsultarImpressao.Size = new System.Drawing.Size(92, 34);
            this.btnConsultarImpressao.TabIndex = 4;
            this.btnConsultarImpressao.Text = "Consultar Protocolo";
            this.btnConsultarImpressao.UseVisualStyleBackColor = true;
            this.btnConsultarImpressao.Click += new System.EventHandler(this.btnConsultarImpressao_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Protocolo Impressão";
            // 
            // txtProtocoloImpressao
            // 
            this.txtProtocoloImpressao.Location = new System.Drawing.Point(10, 80);
            this.txtProtocoloImpressao.Name = "txtProtocoloImpressao";
            this.txtProtocoloImpressao.Size = new System.Drawing.Size(107, 20);
            this.txtProtocoloImpressao.TabIndex = 2;
            // 
            // btnSolicitarImpressao
            // 
            this.btnSolicitarImpressao.Location = new System.Drawing.Point(134, 19);
            this.btnSolicitarImpressao.Name = "btnSolicitarImpressao";
            this.btnSolicitarImpressao.Size = new System.Drawing.Size(93, 23);
            this.btnSolicitarImpressao.TabIndex = 1;
            this.btnSolicitarImpressao.Text = "Solic. Impressão";
            this.btnSolicitarImpressao.UseVisualStyleBackColor = true;
            this.btnSolicitarImpressao.Click += new System.EventHandler(this.btnSolicitarImpressao_Click);
            // 
            // cbbTipoImpressao
            // 
            this.cbbTipoImpressao.FormattingEnabled = true;
            this.cbbTipoImpressao.Items.AddRange(new object[] {
            "0-Normal",
            "1-Carnê Duplo",
            "2-Carnê Triplo",
            "3-Imp. Dupla",
            "4-Normal (Marca d\'agua)",
            "99-Personalizada"});
            this.cbbTipoImpressao.Location = new System.Drawing.Point(10, 21);
            this.cbbTipoImpressao.Name = "cbbTipoImpressao";
            this.cbbTipoImpressao.Size = new System.Drawing.Size(110, 21);
            this.cbbTipoImpressao.TabIndex = 0;
            this.cbbTipoImpressao.SelectedIndexChanged += new System.EventHandler(this.cbbTipoImpressao_SelectedIndexChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnDescartarBoleto);
            this.groupBox5.Controls.Add(this.btnConsultarBoleto);
            this.groupBox5.Controls.Add(this.btnIncluirBoleto);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.txtIDIntegracao);
            this.groupBox5.Location = new System.Drawing.Point(292, 11);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(237, 69);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Inclusão e Consulta";
            // 
            // btnConsultarBoleto
            // 
            this.btnConsultarBoleto.Location = new System.Drawing.Point(10, 41);
            this.btnConsultarBoleto.Name = "btnConsultarBoleto";
            this.btnConsultarBoleto.Size = new System.Drawing.Size(104, 22);
            this.btnConsultarBoleto.TabIndex = 3;
            this.btnConsultarBoleto.Text = "Consultar ID";
            this.btnConsultarBoleto.UseVisualStyleBackColor = true;
            this.btnConsultarBoleto.Click += new System.EventHandler(this.btnConsultarBoleto_Click);
            // 
            // btnIncluirBoleto
            // 
            this.btnIncluirBoleto.Location = new System.Drawing.Point(10, 15);
            this.btnIncluirBoleto.Name = "btnIncluirBoleto";
            this.btnIncluirBoleto.Size = new System.Drawing.Size(104, 20);
            this.btnIncluirBoleto.TabIndex = 2;
            this.btnIncluirBoleto.Text = "Incluir Boleto";
            this.btnIncluirBoleto.UseVisualStyleBackColor = true;
            this.btnIncluirBoleto.Click += new System.EventHandler(this.btnIncluirBoleto_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(161, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "ID Integração";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtIDIntegracao
            // 
            this.txtIDIntegracao.Location = new System.Drawing.Point(133, 15);
            this.txtIDIntegracao.Name = "txtIDIntegracao";
            this.txtIDIntegracao.Size = new System.Drawing.Size(100, 20);
            this.txtIDIntegracao.TabIndex = 0;
            // 
            // btnDescartarBoleto
            // 
            this.btnDescartarBoleto.Location = new System.Drawing.Point(135, 41);
            this.btnDescartarBoleto.Name = "btnDescartarBoleto";
            this.btnDescartarBoleto.Size = new System.Drawing.Size(97, 21);
            this.btnDescartarBoleto.TabIndex = 4;
            this.btnDescartarBoleto.Text = "Descartar Boleto";
            this.btnDescartarBoleto.UseVisualStyleBackColor = true;
            this.btnDescartarBoleto.Click += new System.EventHandler(this.btnDescartarBoleto_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnConsultarEmail);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Controls.Add(this.txtProtocoloEmail);
            this.groupBox6.Controls.Add(this.btnEnvioEmail);
            this.groupBox6.Location = new System.Drawing.Point(299, 208);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(229, 139);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Email";
            // 
            // btnEnvioEmail
            // 
            this.btnEnvioEmail.Location = new System.Drawing.Point(11, 31);
            this.btnEnvioEmail.Name = "btnEnvioEmail";
            this.btnEnvioEmail.Size = new System.Drawing.Size(98, 33);
            this.btnEnvioEmail.TabIndex = 0;
            this.btnEnvioEmail.Text = "Enviar Email";
            this.btnEnvioEmail.UseVisualStyleBackColor = true;
            this.btnEnvioEmail.Click += new System.EventHandler(this.btnEnvioEmail_Click);
            // 
            // txtProtocoloEmail
            // 
            this.txtProtocoloEmail.Location = new System.Drawing.Point(15, 101);
            this.txtProtocoloEmail.Name = "txtProtocoloEmail";
            this.txtProtocoloEmail.Size = new System.Drawing.Size(202, 20);
            this.txtProtocoloEmail.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(74, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Protocolo Email";
            // 
            // btnConsultarEmail
            // 
            this.btnConsultarEmail.Location = new System.Drawing.Point(119, 31);
            this.btnConsultarEmail.Name = "btnConsultarEmail";
            this.btnConsultarEmail.Size = new System.Drawing.Size(99, 33);
            this.btnConsultarEmail.TabIndex = 3;
            this.btnConsultarEmail.Text = "Consulta Email";
            this.btnConsultarEmail.UseVisualStyleBackColor = true;
           // this.btnConsultarEmail.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 531);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.txtRetorno);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "new";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ColorDialog colorDialog2;
        private System.Windows.Forms.ColorDialog colorDialog3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdProducao;
        private System.Windows.Forms.RadioButton rdHomologacao;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txBoxTokenSH;
        private System.Windows.Forms.TextBox txBoxCNPJCedente;
        private System.Windows.Forms.TextBox txBoxCNPJSH;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnCadastroCedente;
        private System.Windows.Forms.Button btnCadastroConta;
        private System.Windows.Forms.RichTextBox txtRetorno;
        private System.Windows.Forms.Button btnCadastroConvenio;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cbbTipoImpressao;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtProtocoloImpressao;
        private System.Windows.Forms.Button btnSolicitarImpressao;
        private System.Windows.Forms.Button btnConsultarImpressao;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIDIntegracao;
        private System.Windows.Forms.Button btnConsultarBoleto;
        private System.Windows.Forms.Button btnIncluirBoleto;
        private System.Windows.Forms.Button btnDescartarBoleto;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnEnvioEmail;
        private System.Windows.Forms.Button btnConsultarEmail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtProtocoloEmail;
    }
}

